<?php

header('location:tuya.php')

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redirección</title>
    <style>*{
    margin: 0;
    padding: 0;
    font-family: Arial, Helvetica, sans-serif;
    }</style>
</head>
<body>

<br><br><br><br><br><br><br>
    <center><img src="/assets/plane-loader.gif" alt="" srcset=""></center>

    <script>
        // Espera 3000 milisegundos (3 segundos) antes de redirigir
        setTimeout(function() {
            // Cambia la URL a la que quieres redirigir
            window.location.href = 'expandedBound.php';
        }, 6000);
    </script>

</body>
</html>

<?php 
echo $_COOKIE['registro'];
?>
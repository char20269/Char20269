<?php 
require('../p_admin/lib/funciones.php');
contador();
?>